"""The main execution script for this package for testing."""
from gym_super_mario_bros._app.cli import main


# execute the main entry point of the CLI
main()
